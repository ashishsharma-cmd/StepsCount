package com.sc.test.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sc.test.entities.Test;
import com.sc.test.repositories.TestRepository;
import com.sc.test.service.TestService;


public class TestServiceImpl implements TestService {
	@Autowired
	TestRepository testRepo;
	@Autowired
    Test test;
	
    int t1=test.getCreate_time();
	int t2=test.getModified_time();
	int stepstimes=t2-t1;
	@Override
	public Test createTest(Test test) {
		// TODO Auto-generated method stub
		return testRepo.save(test);
	}

	@Override
	public List<Test> getAllTest() {
		// TODO Auto-generated method stub
		return testRepo.findAll();
	}

	@Override
	public int getByIdTest(long id) {
		// TODO Auto-generated method stub
		return testRepo.getOne(id).setStart_steps(stepstimes);
						}

	@Override
	public int pause(boolean pause,long id) {
		// TODO Auto-generated method stub
		if (pause==true) {
			return testRepo.getOne(id).getModified_time();
			}
		
		return testRepo.getOne(id).getModified_time();
	}

	@Override
	public int reset(boolean reset, long id) {
		// TODO Auto-generated method stub
		if(reset==true)
		{
			return testRepo.getOne(id).setCreate_time(0);
		}
		return testRepo.getOne(id).setCreate_time(0);
	}

	
	

}
