package com.sc.test.service;

import java.util.List;

import com.sc.test.entities.Test;

public interface TestService {
public Test createTest(Test test);
public List<Test> getAllTest();
public int getByIdTest(long id);
public int pause(boolean pause,long id);
public int reset(boolean reset,long id);
}
