package com.sc.test.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name= "test")
public class Test {
	 @Column(name="id")
	 private long id;
	@CreationTimestamp
	 @Column(name="create_time")
	private int create_time;
	@UpdateTimestamp
	 @Column(name="modified_time")
	int modified_time;
	 @Column(name="number_steps")
	int number_steps;
	 @Column(name="start_steps")
	int start_steps;
	  
	 public boolean isPause() {
		return pause;
	}
	public void setPause(boolean pause) {
		this.pause = pause;
	}
	public boolean isReset() {
		return reset;
	}
	public void setReset(boolean reset) {
		this.reset = reset;
	}
	boolean pause;
	 
	 boolean reset;
	 
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public int getCreate_time() {
		return create_time;
	}
	public int setCreate_time(int create_time) {
		return this.create_time = create_time;
	}
	public int getModified_time() {
		return modified_time;
	}
	public void setModified_time(int modified_time) {
		this.modified_time = modified_time;
	}
	public int getNumber_steps() {
		return number_steps;
	}
	public void setNumber_steps(int number_steps) {
		this.number_steps = number_steps;
	}
	public int getStart_steps() {
		return start_steps;
	}
	public int setStart_steps(int start_steps) {
		return this.start_steps = start_steps;
	}
	@Override
	public String toString() {
		return "Test [pause=" + pause + ", reset=" + reset + "]";
	}
	
}
