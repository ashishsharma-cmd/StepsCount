package com.sc.test.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.sc.test.entities.Test;
import com.sc.test.serviceImpl.TestServiceImpl;

@RestController
@RequestMapping("/api")
public class Testcontroller {
@Autowired
 private TestServiceImpl tsi;

@GetMapping("/Api")
public void  Api(){
System.out.println("Welcome");
	
}

@PostMapping("/createtest")
public Test createTest(Test test)
{
	 return tsi.createTest(test);
	
	}
@GetMapping("/user/{id}")
public int getTest(@PathVariable long id)
{
	return tsi.getByIdTest(id);
}
@GetMapping("/user")
public ModelAndView  getTest()
{
	ModelAndView mv=new ModelAndView();
	List<Test>  test=tsi.getAllTest();
	mv.addObject(test);
	 return mv;
}

@GetMapping("/pause/{true}/{id}")
public int pause(@RequestParam boolean pause,long id)
{
	return tsi.pause(pause, id);
	
}
@GetMapping("/reset/{true}/{id}")
public int reset(@RequestParam boolean reset,long id)
{
	return tsi.reset(reset, id);
}




}
