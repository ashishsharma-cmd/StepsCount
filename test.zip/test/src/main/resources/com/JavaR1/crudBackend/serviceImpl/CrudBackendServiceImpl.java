package com.JavaR1.crudBackend.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.JavaR1.crudBackend.entities.User;
import com.JavaR1.crudBackend.repositories.UserRepository;
import com.JavaR1.crudBackend.service.CrudBackendService;

public class CrudBackendServiceImpl implements CrudBackendService {
@Autowired
UserRepository userRepository;

	@Override
	public List<User> getUsers() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public Optional<User> getUser(Long id) {
		// TODO Auto-generated method stub
		return userRepository.findById(id);
	}

	@Override
	public User createUser(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
	}

}
