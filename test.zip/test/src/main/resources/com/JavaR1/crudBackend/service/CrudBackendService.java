package com.JavaR1.crudBackend.service;

import java.util.List;
import java.util.Optional;

import com.JavaR1.crudBackend.entities.User;



public interface CrudBackendService {
	public List<User>  getUsers();
	public Optional<User> getUser(Long id);
	public User createUser(User user);
	
}
