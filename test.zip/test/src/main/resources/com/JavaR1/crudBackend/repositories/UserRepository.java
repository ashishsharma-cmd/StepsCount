package com.JavaR1.crudBackend.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.JavaR1.crudBackend.entities.User;

@Repository
public interface UserRepository  extends JpaRepository<User, Long>{

}
