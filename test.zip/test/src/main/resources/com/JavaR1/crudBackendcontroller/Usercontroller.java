package com.JavaR1.crudBackendcontroller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.JavaR1.crudBackend.entities.User;
import com.JavaR1.crudBackend.service.CrudBackendService;

@RestController
@RequestMapping("/api")
public class Usercontroller {
	@Autowired
	private CrudBackendService crudBackendService;

	@GetMapping("/Api")
	public void  Api(){
System.out.println("Welcome");
		
	}
	
	@GetMapping("/users")
	public List<User>  getUsers(){
		return crudBackendService.getUsers();
		
	}
	@GetMapping("/user/{id}")
	public Optional<User> getUser(@PathVariable Long id){
		 return crudBackendService.getUser(id);		
		
	}

	
	@PostMapping("/user")
	public User cretaeUser(User user){
		 return crudBackendService.createUser(user);
		
	}
	

}
