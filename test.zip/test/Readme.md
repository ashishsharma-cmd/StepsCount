# Steps Management 

## Introduction

This application is Build on MVC pattern.It has Pojo,Repositories,service,controller layer.
 which will  return the steps count for the particular id and also it will return the steps count for all the id in HTML form and we can reset as well as we can pause the timer.

# Working
once we run this application by Below command,Automatically one entry will store by running the sql query(schema.sql) and it will take the data from data.sql file  into H2 DB.which we can fetch the data by hitting on the address(http:localhost:8080/api/user).
if we want to get the data of particular id we have to hit the address(http:localhost:8080/user/{id}) and it will communicate with service layer and it will fetch the data from H2 data based on defined business logic.so to paused the timer we have define the flag which will the check the true Or false. if it is true if will stop counting and if it is false it will continue counting.
To reset the counter we are checking  the condition  which will again check true or false if it is true it will reset the counter to Zero. 
To create user :
http://localhost:8080/api/createtest

To Get  Steps timming for all user:
http://localhost:8080/api/user


To Get Steps timming for the Particular User based on id:
http://localhost:8080/api/user/{id}





## Code Samples


public class TestServiceImpl implements TestService {
	
    int t1=test.getCreate_time();
	int t2=test.getModified_time();
	int stepstimes=t2-t1;
	@Override
	public Test createTest(Test test) {
		// TODO Auto-generated method stub
		return testRepo.save(test);
	}

	@Override
	public List<Test> getAllTest() {
		// TODO Auto-generated method stub
		return testRepo.findAll();
	}

	@Override
	public int getByIdTest(long id) {
		// TODO Auto-generated method stub
		return testRepo.getOne(id).setStart_steps(stepstimes);
						}
		
}


## Installation

# To Build :

mvn clean install -DskipTests

# To Run:

mvn spring-boot:run

# DB Used:
H2
# FrameWork:
Spring-Boot

